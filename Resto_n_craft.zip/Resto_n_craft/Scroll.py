#!/usr/bin/python3
# -*- coding: utf-8 -*-

from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *

import sys

class MyWidget(QWidget):
    
    def __init__(self):
    
        QWidget.__init__(self)
        
        self.plate =  QImage("reshaped/assiette.png")
        self.leftScroll = QListWidget(self)
        self.rightScroll = QListWidget(self)
        self.rightItem = {}
        self.leftItem = {}
        self.plateElement = []
        self.selectedIngredient = []
        self.window = 0
        self.Menu1 = None
        self.Menu2 = None
        self.Menu3 = None
        self.Menu4 = None
        self.label = None
        self.valid = None
        self.Return = None
        self.payment1 = None
        self.payment2 = None
        self.payment3 = None
        self.payment4 = None
        self.payment5 = None
        self.layout = None
        
    def lecture(self):    
        fichier = open("liste_bouffe.txt", "r")
        tableau = fichier.read().split(";")
        return  tableau   
        
    def init(self):
        
        # Menu
        self.Menu1 = QPushButton(QIcon("reshaped/assiette.png"),"",self)
        self.Menu1.setIconSize(QSize(920, 320))
        self.Menu2 = QPushButton(QIcon("reshaped/poulet+.png"),"",self)
        self.Menu2.setIconSize(QSize(920, 320))
        self.Menu3 = QPushButton(QIcon("reshaped/steak.png"),"",self)
        self.Menu3.setIconSize(QSize(920, 320))
        self.Menu4 = QPushButton(QIcon("reshaped/oeuf+.png"),"",self)
        self.Menu4.setIconSize(QSize(920, 320))
        
        self.Menu1.clicked.connect(self.hideMenu)

        # Title
        title = QPixmap("foodmenu.png")
        title = title.scaled(QSize(1890, 320))
        self.label = QLabel(self)
        self.label.setPixmap(title)

        # Layout
        self.layout = QGridLayout()
        self.layout.addWidget(self.Menu1, 1, 0)
        self.layout.addWidget(self.Menu2, 1, 1)
        self.layout.addWidget(self.Menu3, 2, 0)
        self.layout.addWidget(self.Menu4, 2, 1)
        self.layout.addWidget(self.label, 0, 0, 1, 2)

        self.setLayout(self.layout)
        
        # Payment
        bill = QPixmap("PQT_projet/addition.png")
        bill = bill.scaled(QSize(800, 800))
        self.payment1 = QLabel(self)
        self.payment1.setPixmap(bill)
        
        self.payment2 = QPushButton(QIcon("PQT_projet/CB.png"), "", self)
        self.payment2.setIconSize(QSize(200, 150))
        self.payment3 = QPushButton(QIcon("PQT_projet/cheque.jpeg"), "", self)
        self.payment3.setIconSize(QSize(200, 150))
        self.payment4 = QPushButton(QIcon("PQT_projet/especes.jpg"), "", self)
        self.payment4.setIconSize(QSize(200, 150))
        self.payment5 = QPushButton(QIcon("PQT_projet/ticket.png"), "", self)
        self.payment5.setIconSize(QSize(200, 150))
        
        self.payment2.clicked.connect(self.payment)
        self.payment3.clicked.connect(self.payment)
        self.payment4.clicked.connect(self.payment)
        self.payment5.clicked.connect(self.payment)
        
        self.payment1.hide()
        self.payment2.hide()
        self.payment3.hide()
        self.payment4.hide()
        self.payment5.hide()
        
        

        # Plate
        self.valid = QPushButton("Valider",  self)
        self.valid.resize(100,  50)
        self.valid.move(1500,  900)
        self.valid.clicked.connect(self.showPayment)
        self.valid.hide()
        
        self.Return = QPushButton("Retour",  self)
        self.Return.resize(100,  50)
        self.Return.move(400,  900)
        self.Return.clicked.connect(self.returnMenu)
        self.Return.hide()
        
        listeIngredient = self.lecture()
        
        for i in listeIngredient:
            self.leftItem[i] = QListWidgetItem(self.leftScroll)
            self.leftItem[i].setIcon(QIcon(i))
            self.leftScroll.addItem(self.leftItem[i])
            
        # Scroll Parameter
        self.leftScroll.resize(180, 1080)
        self.leftScroll.setFlow(QListWidget.TopToBottom)
        self.leftScroll.setIconSize(QSize(150, 150))
        self.leftScroll.hide()
        
        self.rightScroll.move(1740, 0)
        self.rightScroll.resize(180, 1080)
        self.rightScroll.setFlow(QListWidget.TopToBottom)
        self.rightScroll.setIconSize(QSize(150, 150))
        self.rightScroll.hide()
        
        self.leftScroll.itemClicked.connect(self.leftItemClicked)
        self.rightScroll.itemClicked.connect(self.rightItemClicked)
        
    def returnMenu(self):
        self.Menu1.show()
        self.Menu2.show()
        self.Menu3.show()
        self.Menu4.show()
        self.label.show()
        self.leftScroll.hide()
        self.rightScroll.hide()
        self.valid.hide()
        self.Return.hide()
        self.window = 0
        self.update()
    def payment(self):
        self.window = 2
        
        self.payment1.hide()
        self.payment2.hide()
        self.payment3.hide()
        self.payment4.hide()
        self.payment5.hide()
        
        self.update()
    def showPayment(self):
        self.window = 0
        
        self.leftScroll.hide()
        self.rightScroll.hide()
        self.valid.hide()
        self.Return.hide()
        self.update()
        
        self.layout.addWidget(self.payment1, 0, 0, 4, 1)
        self.layout.addWidget(self.payment2, 1, 1)
        self.layout.addWidget(self.payment3, 1, 2)
        self.layout.addWidget(self.payment4, 2, 1)
        self.layout.addWidget(self.payment5, 2, 2)
        
        self.payment1.show()
        self.payment2.show()
        self.payment3.show()
        self.payment4.show()
        self.payment5.show()
        
        
    def hideMenu(self):
        self.Menu1.hide()
        self.Menu2.hide()
        self.Menu3.hide()
        self.Menu4.hide()
        self.label.hide()
        self.leftScroll.show()
        self.rightScroll.show()
        self.valid.show()
        self.Return.show()
        self.window = 1
        self.update()
        
    def leftItemClicked(self, item):
    
        listeIngredient = self.lecture()
        
        for ingredient in listeIngredient:
            if self.leftItem[ingredient] == item:
            
                self.rightItem[ingredient] = QListWidgetItem(self.rightScroll)
                self.rightItem[ingredient].setIcon(QIcon(ingredient))
                self.rightScroll.addItem(self.rightItem[ingredient])
                self.selectedIngredient.append(ingredient)
                self.plateElement.append(QImage(ingredient))
                self.leftScroll.takeItem(self.leftScroll.row(item))
                self.update()
                
        
        
    def rightItemClicked(self, item):
        
        for ingredient in self.selectedIngredient:
            if self.rightItem[ingredient] == item:
            
                self.leftItem[ingredient] = QListWidgetItem(self.leftScroll)
                self.leftItem[ingredient].setIcon(QIcon(ingredient))
                self.leftScroll.addItem(self.rightItem[ingredient])
                self.selectedIngredient.remove(ingredient)
                self.plateElement.remove(QImage(ingredient))
                self.rightScroll.takeItem(self.rightScroll.row(item))
                self.update()
        
    
    def paintEvent(self, event):
        painter = QPainter(self)
        if self.window == 1:
            rect = QRect(110,0,1650,1050)
            painter.drawImage(rect, self.plate)
            x=0
            y=0
            for ingredient in self.plateElement:
                element = QRect(600+100*x,280+100*y,200,200)
                painter.drawImage(element, ingredient)           
                x+=1
                if x==6:
                    x=0
                    y+=1
        elif self.window == 2:
            rect = QRect(0,0,1920,1080)
            painter.drawImage(rect, QImage("PQT_projet/merci"))
        
        
class MyWindow(QMainWindow):
    app = QApplication(sys.argv)
    
    def init(self, Widget):
        
        
        self.resize(1920, 1080)
        self.setWindowTitle("Scroll")
        self.setCentralWidget(Widget)
        
       
        
        
def main(args):
    Win = MyWindow()
    Wid = MyWidget()
    Wid.init()
    Win.init(Wid)
    Win.show()
    Win.app.exec_()
    
        
if __name__ == "__main__":
    main(sys.argv)
